*I cannot select a single reference file in the EPI2ME desktop app.* - When running the workflow via the desktop app, you need to provide a directory with reference files. If you only have a single file, you can create a directory to place your reference file inside and select this with the reference input option.

*How are the values in the `acc` column (and other metrics) in the per-read output stats calculated?* -
For details on the per-read stats output files, please refer to the [fastcat/bamstats documentation](https://github.com/epi2me-labs/fastcat#output-format).

If your question is not answered here, please report any issues or suggestions on the [github issues](https://github.com/epi2me-labs/wf-alignment/issues) page or start a discussion on the [community](https://community.nanoporetech.com/).
